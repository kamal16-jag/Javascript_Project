const admin = require('../firebase');
const User = require("../Models/User");

exports.authCheck = async (req,res,callback) =>{
    //console.log("Token is:- "+req.headers.authtoken); //token of user
    try {
        const firebaseUser = await admin.auth().verifyIdToken(req.headers.authtoken);
        //console.log("FIrebase User:- ",firebaseUser);
        req.user = firebaseUser;
        
    callback();
    } catch (error) {
        console.log(error);
        res.status("401").json({
            error : "Invalid or unauthorised token",
        });
    } 
};

exports.adminCheck = async(req,res,next) => {
    const {email} = req.user;
    const adminUser = await User.findOne({email}).exec();

    if(adminUser.role !== "admin"){
        res.status(403).json({error:"Admin resource,Access denied.",
    });
    }else{
        next();
    }
};