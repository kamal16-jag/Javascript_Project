const express = require("express");
const router = express.Router();

const { createPaymentIntent } = require("../Controllers/Stripe");
const { route } = require("./user");
// middleware
const { authCheck } = require("../middlewares/auth");

router.post("/create-payment-intent", authCheck, createPaymentIntent);

module.exports = router;
