const express = require("express");

const router = express.Router();

// middlewares
const { authCheck,adminCheck} = require("../middlewares/Auth");

const {orders,orderStatus} = require("../Controllers/Admin");

//routes
router.get("/admin/orders",authCheck,adminCheck,orders);
router.put("/admin/order-status",authCheck,adminCheck,orderStatus);

module.exports = router;