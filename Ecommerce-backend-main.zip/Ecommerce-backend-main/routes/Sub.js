const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middlewares/Auth");

//controller :- for express front-back end handling i.e req&res
const {create,read,update,remove,list} = require('../Controllers/Sub');

//routes
//to create a category
router.post("/sub",authCheck,adminCheck,create);
//to list all the categories
router.get("/subs",list);
//to read a category
router.get("/sub/:slug",read);
//to update the name and slug of a category
router.put("/sub/:slug",authCheck,adminCheck,update);
//to delete a category
router.delete("/sub/:slug",authCheck,adminCheck,remove);

module.exports = router;
