const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middlewares/Auth");

//controller :- for express front-back end handling i.e req&res
const {createOrUpdateUser,currentUser} = require('../Controllers/Auth');

router.post("/create-or-update-user",authCheck,createOrUpdateUser);
router.post("/current-user",authCheck,currentUser);
router.post("/current-admin",authCheck,adminCheck,currentUser);

module.exports = router;
