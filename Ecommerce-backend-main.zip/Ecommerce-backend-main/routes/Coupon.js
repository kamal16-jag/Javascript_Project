const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middlewares/Auth");

//controller :- for express front-back end handling i.e req&res
const {create,remove,list} = require('../Controllers/Coupon');

//routes
router.post("/coupon",authCheck,adminCheck,create);
router.get("/coupons",list);
router.delete("/coupon/:couponId",authCheck,adminCheck,remove);
module.exports = router;
