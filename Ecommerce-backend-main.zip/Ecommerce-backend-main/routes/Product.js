const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middlewares/Auth");

//controller :- for express front-back end handling i.e req&res
const {create,listAll,remove,read,update,list,searchFilters,productsCount,productStar,listRelated} = require('../Controllers/Product');

//routes
//to create a product
router.post("/product",authCheck,adminCheck,create);
//to get all porducts from the database
router.get("/products/total",productsCount);
router.get("/products/:count",listAll);
router.delete("/product/:slug",authCheck,adminCheck,remove);
router.get("/product/:slug",read);
router.put("/product/:slug",authCheck,adminCheck,update);
router.post("/products",list);
router.put("/product/star/:productId",authCheck,productStar);
//related products
router.get("/product/related/:productId",listRelated);
//serach
router.post("/search/filters",searchFilters);
module.exports = router;
