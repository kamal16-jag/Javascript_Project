const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middlewares/Auth");

//controller :- for express front-back end handling i.e req&res
const {create,read,update,remove,list,getSubs} = require('../Controllers/Category');

//routes
//to create a category
router.post("/category",authCheck,adminCheck,create);
//to list all the categories
router.get("/categories",list);
//to read a category
router.get("/category/:slug",read);
//to update the name and slug of a category
router.put("/category/:slug",authCheck,adminCheck,update);
//to delete a category
router.delete("/category/:slug",authCheck,adminCheck,remove);
//to read a sub for product page
router.get("/category/subs/:_id",getSubs);
module.exports = router;
