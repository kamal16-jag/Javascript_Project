export const CODReducer = (state= false,acition)=>{
    switch(acition.type){
        case "COD":
            return acition.payload;
        default:
            return state;
    }
}