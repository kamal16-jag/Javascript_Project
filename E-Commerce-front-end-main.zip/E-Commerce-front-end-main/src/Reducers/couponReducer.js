export const couponReducer = (state= false,acition)=>{
    switch(acition.type){
        case "COUPON_APPLIED":
            return acition.payload;
        default:
            return state;
    }
}