 import firebase from 'firebase';
 // Your web app's Firebase configuration
 const firebaseConfig = {
    apiKey: "AIzaSyCKVzph2FetbZ74W52W6h-Wy08duVJWOUE",
    authDomain: "ecommerce-7b829.firebaseapp.com",
    projectId: "ecommerce-7b829",
    storageBucket: "ecommerce-7b829.appspot.com",
    messagingSenderId: "796396342555",
    appId: "1:796396342555:web:95120a535d4d0af18297be"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export const auth=firebase.auth()
  export const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
