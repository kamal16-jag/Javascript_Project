import React,{useEffect} from 'react'
import {Switch,Route} from 'react-router-dom'
import Login from './Pages/auth/Login'
import Register from './Pages/auth/Register'
import Home from './Pages/Home'
import Header from './Components/nav/Header'
import {ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import RegisterComplete from './Pages/auth/RegisterComplete'
import {auth} from './Firebase'
import {useDispatch} from 'react-redux'
import ForgotPassword from './Pages/auth/ForgotPassword'
import {currentUser} from './Functions/Auth';
import History from './Pages/user/History';
import UserRoute from './Components/routes/UserRoute';
import AdminRoute from './Components/routes/AdminRoute';
import Password from './Pages/user/Password';
import Wishlist from './Pages/user/Wishlist';
import AdminDashboard from  './Pages/admin/AdminDashboard';
import CategoryCreate from './Pages/admin/Category/categoryCreate';
import CategoryUpdate from './Pages/admin/Category/categoryUpdate';
import SubCreate from './Pages/admin/Sub/subCreate';
import SubUpdate from './Pages/admin/Sub/subUpdate';
import ProductCreate from './Pages/admin/Product/productCreate'
import AllProducts from './Pages/admin/Product/AllProducts'
import ProductUpdate from './Pages/admin/Product/productUpdate'
import Product from "./Pages/Product";
import CategoryHome from "./Pages/Category/CategoryHome";
import SubHome from "./Pages/Sub/SubHome";
import Shop from "./Pages/Shop";
import Cart from "./Pages/Cart";
import SideDrawer from "./Components/Drawer/SideDrawer";
import Checkout from "./Pages/Checkout";
import CreateCoupon from './Pages/admin/Coupons/createCoupons';
import Payement from './Pages/Payment';
const App = ({history}) =>{
  const dispatch = useDispatch();

  //to check firebase with state
  useEffect(()=>{
    const unsubscribe = auth.onAuthStateChanged(async (user) =>{
      if(user){
        const idTokenResult = await user.getIdTokenResult();
        console.log(user);
        currentUser(idTokenResult.token)
            .then((res)=>{
                dispatch({
                    type:'LOGGED_IN_USER',
                    payload:{
                      name: res.data.name,
                      email: res.data.email,
                      role:res.data.role,
                      _id: res.data._id,
                      token:idTokenResult.token
                    },
                  });
            })
            .catch((err) => console.log(err));
      }
    });
    //
    return unsubscribe;
  },[history,dispatch]);
  return (
    <>
    <Header />
    <SideDrawer />
    <ToastContainer/>
    <Switch>
      <Route exact path="/" component={Home}></Route>
      <Route exact path="/login" component={Login}></Route>
      <Route exact path="/register" component={Register}></Route>
      <Route exact path="/register/complete" component={RegisterComplete}></Route>
      <Route exact path="/forgot/password" component={ForgotPassword}></Route>
      <UserRoute exact path="/user/history" component={History}/>
      <UserRoute exact path="/user/password" component={Password}/>
      <UserRoute exact path="/user/wishlist" component={Wishlist}/>
      <AdminRoute exact path="/admin/dashboard" component={AdminDashboard}/>
      <AdminRoute exact path="/admin/products" component={AllProducts}/>
      <AdminRoute exact path="/admin/category/" component={CategoryCreate}/>
      <AdminRoute exact path="/admin/category/:slug" component={CategoryUpdate}/>
      <AdminRoute exact path="/admin/sub/" component={SubCreate}/>
      <AdminRoute exact path="/admin/sub/:slug" component={SubUpdate}/>
      <AdminRoute exact path="/admin/product/" component={ProductCreate}/>
      <AdminRoute exact path="/admin/product/:slug" component={ProductUpdate}/>
      <Route exact path="/product/:slug" component={Product}></Route>
      <Route exact path="/category/:slug" component={CategoryHome}></Route>
      <Route exact path="/sub/:slug" component={SubHome}></Route>
      <Route exact path="/shop" component={Shop}></Route>
      <Route exact path="/cart" component={Cart}></Route>
      <Route exact path="/checkout" component={Checkout}></Route>
      <AdminRoute exact path="/admin/coupon" component={CreateCoupon} />
      <UserRoute exact path="/payment" component={Payement}/>
    </Switch>
    </>
  );
}

export default App;
