import React from 'react';
import StarRating from 'react-star-ratings';

export const showAverage = (p) =>{
    if(p && p.ratings){
        //Average ratings
        let ratingsArray = p && p.ratings;
        let total = [];
        let length = ratingsArray.length;

        ratingsArray.map((r)=>
            total.push(r.star)
        );
        let totalReduced = total.reduce((p,n)=> p+n,0);
        //console.log("Total Reduced :-",totalReduced);
        let highest = length * 5;
        //console.log("Highest total ",highest);

        let result = (totalReduced * 5)/highest;
        //console.log("Average rating:- ",result);
        return(
            <div className="text-center pb-3">
                <span>
                    <StarRating
                    rating={result}
                    starRatedColor = "red"
                    starDimension = "20px"
                    starSpacing = "2px"
                    ediiting={false}
                    />({p.ratings.length})
                </span>
            </div>
        );
    }
}
