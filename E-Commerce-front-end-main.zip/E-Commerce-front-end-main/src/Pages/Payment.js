import React from 'react';
import {loadStripe} from '@stripe/stripe-js';
import {Elements} from '@stripe/react-stripe-js';
import StripeCheckout from '../Components/StripeCheckout';
import '../stripe.css';
//load stripe outside of components render to avoid recraeting stripe objects

const promise = loadStripe('pk_test_51Is7OvLveOgWIoSWeimSzAW9Nj1xyraiep30jUFjRn82Ieq9tCspdamH24BgHIK4mikUd6L01SFCEF7fzPc2iISG00LnHPpC8j');


const Payment = () =>{
    return(
        <div className="container p-5 text-center">
            <h4>Complete your purchase</h4>
            <Elements stripe={promise}>
            <div className="col-md-8 offset-2">
                <StripeCheckout />
            </div>
            </Elements>
        </div>
    );
}

export default Payment;