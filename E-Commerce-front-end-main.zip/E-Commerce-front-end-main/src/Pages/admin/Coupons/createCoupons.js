import React, { useState,useEffect} from 'react';
import {useSelector} from 'react-redux';
import {toast} from 'react-toastify';
import DatePicker from 'react-datepicker';
import{getCoupons,removeCoupons,createCoupons} from "../../../Functions/Coupon";
import 'react-datepicker/dist/react-datepicker.css';
import {DeleteOutlined} from '@ant-design/icons';
import AdminNav from "../../../Components/nav/adminNav";
const CreateCoupon = () =>{
  const [name,setName] = useState("");
  const [expiry,setExpiry] = useState("");
  const [discount,setDiscount] = useState("");
  const [loading,setLoading] = useState(false);
  const [coupons,setCoupons] = useState([]);
  const {user} = useSelector((state)=>({...state}));

  useEffect(()=>{
    loadAllCoupons();
  },[]);
  const loadAllCoupons = () =>getCoupons().then((res)=> setCoupons(res.data));
  const handleSubmit = (e) =>{
    e.preventDefault();
    setLoading(true);
    // console.table(name,expiry,discount);
    createCoupons({name,expiry,discount},user.token).then((res)=>{
      setLoading(false);
      setExpiry("");
      setDiscount("");
      setName("");
      loadAllCoupons();
      toast.success(`${res.data.name} is created`);
    }).catch((error)=>{
      setLoading(false);
      setExpiry("");
      setName("");
      setDiscount("");
      console.log("Create COupon error:-",error);   
    });
  }
  const handleRemove =(couponId) =>{
    if(window.confirm("Delete selected coupon ?")){
      setLoading(true);
      removeCoupons(couponId,user.token).then((res)=>{
        //load all the coupons
        loadAllCoupons();
        setLoading(false);
        toast.error(`${res.data.name} is deleted`);
        setExpiry("");
      setName("");
      setDiscount("");
      }).catch((error)=>{
        console.log(error);
      });
    }
  }
    return(
        <div className="container-fluid">
      <div className="row">
        <div className="col-md-2">
          <AdminNav />
        </div>
        <div className="col-md-5">
            {loading ?<h4 className="text-danger">Loading...</h4> :<h4>Coupon</h4>}
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="text-muted">Name</label>
                <input 
                type="text"
                className="form-control"
                onChange={(e)=>setName(e.target.value)}
                value={name}
                autoFocus
                required
                />
              </div>

              <div className="form-group">
                <label className="text-muted">Discount %</label>
                <input 
                type="text"
                className="form-control"
                onChange={(e)=>setDiscount(e.target.value)}
                value={discount}
                required
                />
              </div>
              <div className="form-group">
                <label className="text-muted">Expiry</label><br/>
                <DatePicker 
                className="form-control"
                selected={new Date()}
                onChange={(date) =>setExpiry(date)}
                value={expiry}
                required
                 />
              </div>
              <button className="btn btn-outline-primary">Save</button>
            </form>
            <br/>
            <h4>{coupons.length}</h4>
            <table className="table table-bordered">
              <thead className="thead-light">
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">expiry</th>
                  <th scope="col">Discount</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {coupons.map((c)=><tr key={c._id}>
                  <td >{c.name}</td>
                  <td >{new Date(c.expiry).toLocaleDateString()}</td>
                  <td >{c.discount}%</td>
                  <td className="text-center"><DeleteOutlined className="text-danger" onClick={()=>handleRemove(c._id)} /></td>
                  
                </tr>)}
              </tbody>
            </table>
        </div>
        </div>
        </div>
    )
}

export default CreateCoupon;