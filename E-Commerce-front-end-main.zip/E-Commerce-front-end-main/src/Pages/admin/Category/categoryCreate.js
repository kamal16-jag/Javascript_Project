import React ,{useState,useEffect}from 'react';
import AdminNav from '../../../Components/nav/adminNav';
import {toast} from 'react-toastify';
import {useSelector} from 'react-redux';
import {Link} from 'react-router-dom';
import { 
    EditOutlined,DeleteOutlined } from '@ant-design/icons';
import {createCategory,getCategories,removeCategory} from '../../../Functions/Category';
import CategoryForm from '../../../Components/Forms/categoryForm';
import LocalSearch from '../../../Components/Forms/LocalSearch';

const CategoryCreate = () =>
{
    const [name,setName] = useState("");
    const [loading,setLoading] = useState(false);
    const [categories,setCategories] = useState([]);

    //step 1 to search category
    const [keyword,setKeyword] = useState("");

    useEffect(() =>{
        loadCategories();
    },[]);

    const loadCategories = () => getCategories().then((c) => setCategories(c.data));
    const {user} = useSelector((state)=>({...state}));
    
    


    //step 4
    const searched = (keyword) => (c) => c.name.toLowerCase().includes(keyword);


    const handleSubmit = (e) =>{
        e.preventDefault();
        setLoading(true);
        createCategory({name},user.token)
        .then((res)=>{
            setLoading(false);
            toast.success(`${res.data.name} is created`);
            loadCategories();   
            setName("");
        }).catch((err) =>{
            setLoading(false);
            console.log(err);
            if(err.response.status === 400)toast.error(err.message);
            setName("");
        });
    }
    const handleRemove = async(slug,name) =>{
        if(window.confirm(`Delete ${name} ? `)){
            setLoading(true);

            removeCategory(slug,user.token)
            .then((res)=>{
                loadCategories();
                setLoading(false);
                toast.success(`${res.data.name} is Delted`);
            }).catch((err) =>{
                if(err.response.status === 400){
                    setLoading(false);
                    toast.error(err.message);
                }
            });
        }
    }
    return(
        <div className="container-fluid">
        <div className="row">
        <div className="col-sm-3 md-2"><AdminNav/></div> 
        <div className="col-sm-5">
            {loading ? <h4 className="text-danger">Loading...</h4>:<h4>Create Category</h4>}
            <CategoryForm handleSubmit={handleSubmit} name={name} setName={setName}/>
            <hr/>
            {/* step 2 */}
            
            <LocalSearch keyword={keyword} setKeyword={setKeyword}/>
            
            {/* step 5 - added search as the middleware
            filter is javascript function */}
            {categories.filter(searched(keyword)).map((c) =>(
                <div className="alert alert-danger" key={c._id}>
                    {c.name}
                    <span className="btn btn-sm float-right" onClick={ () => handleRemove(`${c.slug}`,`${c.name}`)}><DeleteOutlined className="text-danger"/></span>
                    <Link className="btn btn-sm float-right" to={`/admin/category/${c.slug}`}><EditOutlined className="text-warning"/></Link>
                </div>               
            ))}
        </div>
        </div>
    </div>
    );
}

export default CategoryCreate;