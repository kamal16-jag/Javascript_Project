import React ,{useState,useEffect}from 'react';
import AdminNav from '../../../Components/nav/adminNav';
import {toast} from 'react-toastify';
import {useSelector} from 'react-redux';
//import {useParams} from 'react-router-dom'; we can use this as well to de-structure slug 
import {getCategory,updateCategory} from '../../../Functions/Category';
import CategoryForm from '../../../Components/Forms/categoryForm';

const CategoryUpdate = ({history,match}) =>
{
    //using match to access slug and history for redirection
    const {user} = useSelector((state)=>({...state}));
    const [name,setName] = useState("");
    const [loading,setLoading] = useState(false);
    
    const loadCategory = () => getCategory(match.params.slug).then((c) => setName(c.data.name));
    useEffect(() =>{
        loadCategory();
    });
    
    const handleSubmit = (e) =>{
        e.preventDefault();
        setLoading(true);
        updateCategory(match.params.slug,{name},user.token)
        .then((res)=>{
            setLoading(false);
            toast.success(`${name} is Updated`);
            //loadCategory();   
            setName("");
            history.push("/admin/category");
        }).catch((err) =>{
            setLoading(false);
            console.log(err);
            if(err.response.status === 400)toast.error(err.message);
            setName("");
        });
    }
    
    return(
        <div className="container-fluid">
        <div className="row">
        <div className="col-sm-3 md-2"><AdminNav/></div> 
        <div className="col-sm-5">
            {loading ? <h4 className="text-danger">Loading...</h4>:<h4>Update Category</h4>}
            <CategoryForm handleSubmit={handleSubmit} name={name} setName={setName}/>
        </div>
        </div>
    </div>
    );
}

export default CategoryUpdate;