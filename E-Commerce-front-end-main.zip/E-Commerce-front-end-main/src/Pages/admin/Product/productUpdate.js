import React, { useState, useEffect } from "react";
import AdminNav from "../../../Components/nav/adminNav";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import ProductUpdateForm from "../../../Components/Forms/productUpdateForm";
import { getCategories, getCategorySubs } from "../../../Functions/Category";
import {LoadingOutlined} from '@ant-design/icons';
import FileUpload from "../../../Components/Forms/fileUpload"; 
import {getProduct,updateProduct} from "../../../Functions/Product";


const initialState = {
  title: "",
  description: "",
  price: "",
  category: "",
  subs: [],
  shipping: "",
  quantity: "",
  images: [],
  colors: ["Black", "Brown", "Silver", "White", "Blue"],
  brands: ["Apple", "Samsung", "Microsoft", "Lenovo", "ASUS"],
  color: "",
  brand: "",
};

const ProductUpdate = ({match,history}) => { //match is available due to browser router
  //and browser router can e found in index.js
  const [values, setValues] = useState(initialState);
  const [subOptions, setSubOptions] = useState([]); 
  const[categories,setCategories] = useState([]);
  const[arrayOfsubs,setArrayofSubIds] = useState([]);
  const[loading,setLoading] = useState(false);
  const [selectedCategory,SetSelectedCategory] = useState("");
  // redux
  const { user } = useSelector((state) => ({ ...state }));

  const {slug} =match.params;
  useEffect(()=>{
    loadProduct();
    loadCategories();
  },[user.token]);
  const loadProduct = () => {
    getProduct(slug).then((p)=>{
      // 1 load single product
      setValues({...values,...p.data});
      //2 load single product category subs 
      getCategorySubs(p.data.category._id)
      .then((res)=>{
        setSubOptions(res.data);
      });
      //3 prepare array of sub id's to show as default sub values
      let arr = [];
      p.data.subs.map((s)=>{
        return arr.push(s._id);
      })
      console.log("Id ARRAY:_ ",(arr));
      setArrayofSubIds((prev)=>arr);

    })
  };
  const loadCategories = () =>
    getCategories().then((c) => {
      
      console.log("dsjajkdashk:-  ",c);
      setCategories(c.data)});
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    values.subs = arrayOfsubs;
    values.category = selectedCategory ? selectedCategory : values.category;
    updateProduct(slug,values,user.token)
    .then((res)=>{
      setLoading(false);  
      toast.success(`${res.data.title} is updated`);
      history.push("/admin/products");
    })
    .catch((err) =>{
      setLoading(false);
      console.log(err);
      toast.error(err.response.data.err);
    });
  }

  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
    // console.log(e.target.name, " ----- ", e.target.value);
  };

  const handleCatagoryChange = (e) => {
    e.preventDefault();
    console.log("CLICKED CATEGORY", e.target.value);
    setValues({ ...values, subs:[],});
    SetSelectedCategory(e.target.value);
    getCategorySubs(e.target.value).then((res) => {
      console.log("SUB OPTIONS ON CATGORY CLICK", res);
      setSubOptions(res.data);
    });
    if(values.category._id === e.target.value){
      loadProduct();
    }
    //clear all subcategories
      setArrayofSubIds([]);
  };
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-2">
          <AdminNav />
        </div>
        <div className="col-md-10">
          {loading ?<h4 className="text-danger"><LoadingOutlined /></h4>  :<h4>Product Update</h4>}
          <hr />
          {JSON.stringify(values)}
          <div className="p-3">
            <FileUpload values={values} setValues={setValues} setLoading={setLoading}/>
          </div>
          <ProductUpdateForm 
          handleSubmit={handleSubmit}
          handleChange={handleChange}
          values={values}
          setValues = {setValues}
          handleCatagoryChange={handleCatagoryChange}
          categories = {categories}
          subOptions ={subOptions}
          arrayOfsubs={arrayOfsubs}
          setArrayofSubIds={setArrayofSubIds}
          selectedCategory ={selectedCategory}
          />
        </div>
      </div>
    </div>
  );
};

export default ProductUpdate;
