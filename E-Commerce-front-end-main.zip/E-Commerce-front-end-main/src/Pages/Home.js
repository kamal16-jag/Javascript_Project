import React from 'react';
import Jumbotron from "../Components/Cards/Jumbotron";
import NewArrivals from "../Components/Home/NewArrivals";
import BestSellers from "../Components/Home/BestSellers";
import CategoryList from "../Components/Category/CategoryList";
import SubList from "../Components/Sub/SubList";
const Home = () =>{


    return(
        <>
        <div className="jumbotron text-warning h1 font-weight-bold text-center">
          
            <Jumbotron text={["New Arrivals","Best Sellers"]}/>
        </div>
        
        <h4 className="text-center p-3 mt-5 mb-5 display-5 jumbotron">New Arrivals</h4>
        <NewArrivals />
        <br/><br/>
        <h4 className="text-center p-3 mt-5 mb-5 display-5 jumbotron">Best Sellers</h4>
        <BestSellers />
        <br/><br/>
        <h4 className="text-center p-3 mt-5 mb-5 display-5 jumbotron">Categories</h4>
        <CategoryList />
        <h4 className="text-center p-3 mt-5 mb-5 display-5 jumbotron">Sub Categories</h4>
        <SubList />
        </>
    );
}

export default Home;