import React ,{useState}from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import ProductCardInCheckout from "../Components/Cards/ProductCartInCheckout";
import {userCart,getZip} from "../Functions/User";
const Cart = ({history}) => {
  const { cart, user } = useSelector((state) => ({ ...state }));
  const dispatch = useDispatch();
  const [loading,setLoading] = useState(false);
  const [zip,setZip] = useState(""); 
  const [disable,setDisable] = useState(true);
  const [success,setSuccess] = useState("undefined");
  
  const getTotal = () => {
    return cart.reduce((currentValue, nextValue) => {
      return currentValue + nextValue.count * nextValue.price;
    }, 0);
  };

  const saveOrderToDb = () => {
    setLoading(true);
    // alert("save order to db");
    // console.log(JSON.stringify(cart));
    // history.push("/checkout");
    userCart(cart,user.token)
    .then((res)=>{
      setLoading(false);
      // console.log("CART POST RES ",res);
    if(res.data.ok) history.push("/checkout");

    }).catch((err)=>{
      setLoading(false);
      console.log("Cart SAVE ERROR:- ",err)
    });
  };

  const showCartItems = () => (
    <table className="table table-bordered">
      <thead className="thead-light">
        <tr>
          <th scope="col">Image</th>
          <th scope="col">Title</th>
          <th scope="col">Price</th>
          <th scope="col">Brand</th>
          <th scope="col">Color</th>
          <th scope="col">Count</th>
          <th scope="col">Shipping</th>
          <th scope="col">Remove</th>
        </tr>
      </thead>

      {cart.map((p) => (
        <ProductCardInCheckout key={p._id} p={p} />
      ))}
    </table>
  );
  const saveCashOrderToDb = () =>{
    setLoading(true);
    // alert("save order to db");
    // console.log(JSON.stringify(cart));
    // history.push("/checkout");
    dispatch({
      type: "COD",
      payload:true,
    });
    userCart(cart,user.token)
    .then((res)=>{
      setLoading(false);
      // console.log("CART POST RES ",res);
    if(res.data.ok) history.push("/checkout");

    }).catch((err)=>{
      setLoading(false);
      console.log("Cart SAVE ERROR:- ",err)
    });
  };
  const check= (e) =>{
    // console.log(zip);
    getZip(zip).then((res)=>{
      // console.log(res.data[0].Status);
      if (res.data[0].Status === "Success") 
      {
        setDisable(false);
        setSuccess(true);
      }else
      {
        setSuccess(false);
      }
      setZip("");
    })
  }
  return (
    <div className="container-fluid pt-2">
      <div className="row">
        <div className="col-md-9">
          <h4>Cart / {cart.length} Product</h4>
          <input 
    type="text"
    className="form-control"
    onChange={(e)=>{
      setZip(e.target.value);}}
    value={zip}
    />
    <button className="btn btn-primary mt-2" onClick={check}>Check Availabilty</button>
          {!cart.length ? (
            <p>
              No products in cart. <Link to="/shop">Continue Shopping.</Link>
            </p>
          ) : (
            showCartItems()
          )}
        </div>
        <div className="col-md-3">
          <h4>Order Summary</h4>
          <hr />
          <p>Products</p>
          {cart.map((c, i) => (
            <div key={i}>
              <p>
                {c.title} x {c.count} = ${c.price * c.count}
              </p>
            </div>
          ))}
          <hr />
          Total: <b>${getTotal()}</b>
          <hr />
          {loading ? <h4 className="text-danger">Loading..</h4> : ""}
          {disable === true ? <><span className="text-danger">* Please Check Availabilty before checkout</span><br/> </>: ""}
          { success === "undefined" ? "" : success === false ? <><span className="text-danger">* Sorry this product is not available in your location</span><br/>
            </> :<><span className="text-success">You can now proceed to checkout</span> </>}
          {user ? (
            <>
            <button
              onClick={saveOrderToDb}
              className="btn btn-sm btn-outline-primary mt-2"
              disabled={!cart.length || disable}
            >
              Proceed to Checkout
            </button>
            <br/>
            <button
              onClick={saveCashOrderToDb}
              className="btn btn-sm btn-outline-danger mt-2"
              disabled={!cart.length || disable}
            >
              Pay cash On delivery
            </button>
            </>
          ) : (
            <button className="btn btn-sm btn-primary mt-2">
              <Link
                to={{
                  pathname: "/login",
                  state: { from: "cart" },
                }}
              >
                Login to Checkout
              </Link>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;
