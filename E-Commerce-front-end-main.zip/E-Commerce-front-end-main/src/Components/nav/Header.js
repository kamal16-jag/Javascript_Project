import React ,{useState}from 'react'
import {Menu,Badge} from 'antd'
import { 
  HomeOutlined,
  UserAddOutlined,
  LogoutOutlined,
  SettingOutlined,
  ShoppingOutlined,
  ShoppingCartOutlined,
  UserOutlined } from '@ant-design/icons';
import {Link} from 'react-router-dom'
import firebase from 'firebase'
import {useDispatch,useSelector} from 'react-redux'
import {useHistory} from 'react-router-dom'
import Search from "../Forms/Search";
const {SubMenu,Item} = Menu;

const Header = () =>{
    const [current,setCurrent] = useState('home');
    const dispatch = useDispatch()
    let history = useHistory();
    let {user,cart} = useSelector((state) => ({...state}));
    const handleClick = (e) =>{
      setCurrent(e.key);
    }
    const logOut = () =>{
      firebase.auth().signOut();
      dispatch({
        type: 'LOGOUT',
        payload:null
      }); 
      history.push('/login');
    }
    return (
        <Menu onClick={handleClick} selectedKeys={[current]} mode="horizontal">
        <Item key="home" icon={<HomeOutlined />} >
          <Link to="/">Home </Link>
        </Item>
        <Item key="shop" icon={<ShoppingOutlined />}>
        <Link to="/shop">Shop</Link>
      </Item>
      <Item key="cart" icon={<ShoppingCartOutlined />}>
        <Link to="/cart"><Badge count={cart.length} offset={[9,2]}>Cart</Badge></Link>
      </Item>
        {!user && (

        <Item key="Register" icon={<UserAddOutlined />} className="float-right">
        <Link to="/register">Register</Link>
        </Item>
        )}
        {!user && (
          
        <Item key="login" icon={<UserOutlined />} className="float-right">
        <Link to="/login">Login</Link>
        </Item>
        )}
        
        {
          user && (<SubMenu key="SubMenu" icon={<SettingOutlined />} title={user.email && user.email.split("@")[0]} className="float-right">
          {user && user.role === "subscriber" ? <Item><Link to="/user/history">Dashboard</Link></Item> :<Item><Link to="/admin/dashboard">Dashboard</Link></Item>}
          <Item icon={<LogoutOutlined />} onClick={logOut}>Log Out</Item>
      </SubMenu>)
        }
        <span className="float-right p-1">
          <Search />
        </span>
      </Menu>
    );
}

export default Header;