import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getCategories } from "../../Functions/Category";
import {Card} from "antd";
import Electronics from "../../Images/electronics.png";
import Mobiles from "../../Images/mobiles.png";
import Home from "../../Images/home.png";
import Appliances from "../../Images/appliances.png";

const {Meta} = Card;

const CategoryList = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);

  //images of categories
  var imgArray = new Array();

  imgArray[0] = new Image();
  imgArray[0].src = Appliances;
  imgArray[1] = new Image();
  imgArray[1].src = Home;
  imgArray[2] = new Image();
  imgArray[2].src = Mobiles;
  imgArray[3] = new Image();
  imgArray[3].src = Electronics;

  useEffect(() => {
    setLoading(true);
    getCategories().then((c) => {
      setCategories(c.data);
      setLoading(false);
    });
  }, []);

  const showCategories = () =>
    categories.map((c,i) => (
      
      <div className="col-md-3">
        <Card
      key={c._id}
      hoverable
      style={{ width: 150 }}
      cover={<img alt="example" src={imgArray[i].src} className="p-2"/>}
    >
      <Meta title={<Link to={`/category/${c.slug}`}>{c.name}</Link>}  />
    </Card>
      </div>
    ));

    
  return (
    <div className="container">
      <div className="row pb-5">
        {loading ? (
          <h4 className="text-center">Loading...</h4>
        ) : (
          showCategories()
        )}
      </div>
    </div>
  );
};

export default CategoryList;
