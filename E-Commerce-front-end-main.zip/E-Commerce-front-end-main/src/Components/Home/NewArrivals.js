import React, { useEffect, useState } from 'react'
import { getProducts,getProductsCount} from "../../Functions/Product";
import PrdouctCard from '../Cards/ProductCard';
import LoadingCard from "../Cards/LoadingCard";
import {Pagination} from 'antd';
const NewArrivals = () =>{
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const[page,setPage] = useState(1);
    const[productsCount,setProductsCount] = useState(0);

    useEffect(() => {
      loadAllProducts();
    },[page]);

    useEffect(() =>{
      getProductsCount()
      .then((res)=>{
        setProductsCount(res.data);
      });
    });
    const loadAllProducts = () => {
        setLoading(true);
        //sort,order,limit
        getProducts('createdAt','desc',page)
          .then((res) => {
              setLoading(false);
            setProducts(res.data);
          })
          .catch((err) => {
            setLoading(false);
            console.log(err);
          });
      };
    return(
        <>
        <div className="container mb-5">
            {loading ? <LoadingCard count={3}/>:<div className="row">
                {products.map((product)=>
                <div className="col-md-4" key={product._id}>
                    <PrdouctCard product={product}/>
                    </div>)}
            </div>}
        </div>
        <Pagination 
        current={page}
        total={(productsCount/3) * 10}
        onChange={(value)=>setPage(value)}
        className="text-center"
        />
        </>
    );
}

export default NewArrivals;