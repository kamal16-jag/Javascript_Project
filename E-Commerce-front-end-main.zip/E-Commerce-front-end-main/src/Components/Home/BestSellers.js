import React, { useEffect, useState } from "react";
import { getProducts,getProductsCount } from "../../Functions/Product";
import ProductCard from "../Cards/ProductCard";
import LoadingCard from "../Cards/LoadingCard";
import {Pagination} from 'antd';
const BestSellers = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const[page,setPage] = useState(1);
  const[productsCount,setProductsCount] = useState(0);

  useEffect(() => {
    loadAllProducts();
  },[page]);

  useEffect(() =>{
    getProductsCount()
    .then((res)=>{
      setProductsCount(res.data);
    });
  })
  const loadAllProducts = () => {
    setLoading(true);
    // sort, order, limit
    getProducts("sold", "desc", page).then((res) => {
      setProducts(res.data);
      setLoading(false);
    });
  };

  return (
    <>
      <div className="container">
        {loading ? (
          <LoadingCard count={3} />
        ) : (
          <div className="row">
            {products.map((product) => (
              <div key={product._id} className="col-md-4">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
        <Pagination 
        current={page}
        total={(productsCount/3) * 10}
        onChange={(value)=>setPage(value)}
        className="text-center pt-5"
        />
      </div>
    </>
  );
};

export default BestSellers;
